@extends('layouts/master')

@section('main')
<style>
    form>span {
  color:red;
   }
    form>p {
  color:green;
   }
  </style>

<h1>Forget Password</h1>

@if (Session::has('error'))
<p>{{Session::get('error')}}</p>
@endif

@if (Session::has('success'))
<p>{{Session::get('success')}}</p>
<span><a href="https://mailtrap.io/">SMTP</a></span>
@endif
<p>sandeepsingh786687@gmail.com
</p>
<form action="{{ route('forgetPasswordLoadFormAction')}}" method="POST">    
    @csrf
Email : <input type="text" name="email" id="email"><br>
<span>@error('email'){{$message}}@enderror</span>
 <br>
 <input type="submit" name="forget" id="forget" value="Forget"><br><br>
</form>

@endsection