@extends('layouts/master')

@section('main')
<style>
    form>span {
  color:red;
   }
    form>p {
  color:green;
   }
  </style>

<h1>Register Form</h1>
<form action="{{ route('studentRegisterFormAction')}}" method="POST">

    @csrf

Name :<input type="text" name="name" id="name"><br>
<span>@error('name'){{$message}}@enderror</span>
<br>
Email : <input type="text" name="email" id="email"><br>
<span>@error('email'){{$message}}@enderror</span>
<br>
Password : <input type="text" name="password" id="pass"><br>
<span>@error('password'){{$message}}@enderror</span>
<br>
Confirm Password: <input type="text" name="password_confirmation" id="c_pass"><br>
<span>@error('c_pass'){{$message}}@enderror</span>
<br>
<input type="submit" name="register" id="name" value="Register"><br><br>
@if (Session::has('success'))
    <p>{{Session::get('success')}}</p>
@endif
     
</form>



@endsection