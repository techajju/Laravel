<!DOCTYPE html> 
<head>
  
    <title>{{ $data['title'] }}</title>
</head>
<body>
    <table>
        <tr>
            <th>Name</th>
            <th>{{ $data['name'] }}</th> 
        </tr>
        <tr>
            <th>Email</th>
            <th>{{ $data['email'] }}</th>
        </tr>
       
        <p>you can use your previous password</p>
        
        <a href="{{ $data['url'] }}">click here to login your account</a>
        <p>Thank you!</p>
    </table>   
</body>
</html>