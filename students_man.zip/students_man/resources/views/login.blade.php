@extends('layouts/master')

@section('main')
<style>
    form>span {
  color:red;
   }
    form>p {
  color:green;
   }
   .row { 
    flex-direction: column !important;
}
.row.login {
    padding: 40px;
    border: 1px solid;
    margin-top: 34px; 
    box-shadow: 0px 2px 2px 0px rgb(0 0 0 / 14%), 0px 3px 1px -2px rgb(0 0 0 / 12%), 0px 1px 5px 0px rgb(0 0 0 / 20%);
    border-radius: 8px; 
    background: #fff;
    width: 42%;
    margin: auto;
}
.container {
    margin-top: 30px;
}
h1 {
    text-align: center;
    text-decoration: underline;
}


@media only screen and (max-width: 986px) {
  .row.login { 
    width: 100%;
}
h1 { 
    font-size: 35px;
    margin-bottom: 13px;
}
}


  </style>


<div class="container">

<div class="row login">





@if (Session::has('error'))
<p>{{Session::get('error')}}</p>
@endif
<h1>Login Form</h1>
<form action="{{ route('loginForm')}}" method="POST">
    @csrf
Email : <input type="text" name="email" id="email"><br>
<span>@error('email'){{$message}}@enderror</span>
<br>
Password : <input type="text" name="password" id="pass"><br>
<span>@error('password'){{$message}}@enderror</span>
 <br>
<input type="submit" class="btn btn-primary"name="login" id="login" value="Login"><br><br>
    
</form>

<a href="/forget-password">Forget Password</a>
@endsection

</div>
</div>
