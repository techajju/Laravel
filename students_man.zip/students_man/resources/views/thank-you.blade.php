@extends('layouts/master')

@section('main')
    <div class="comtainer">
        <div class="text-center">
            <h2>Thanks for submit your exam, {{ Auth::user()->name }}</h2>
            <p> we will review your exam and inform you by email</p>
            <a href="/dashboard" class="btn btn-info"> Go back</a>
        </div>
    </div>


@endsection

  