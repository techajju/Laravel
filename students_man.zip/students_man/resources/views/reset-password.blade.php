@extends('layouts/master')

@section('main')
<style>
    form>span {
  color:red;
   }
    form>p {
  color:green;
   }
  </style>

<h1>Reset Password</h1>
 
<form action="{{ route('resetPasswordLoadFormAction')}}" method="POST">    
    @csrf
    <input type="hidden" name="id" value="{{ $user[0]['id'] }}">

    Password : <input type="text" name="password" id="pass"><br>
    
    <br>
    Confirm Password: <input type="text" name="password_confirmation" id="c_pass"><br>
    
    <br>
   
    <span>@error('password'){{$message}}@enderror</span>
    <br>
 <input type="submit" name="reset" id="reset" value="Reset"><br><br>
</form>

@endsection