@extends('layouts/admin-index')
@section('admin_work')

<h2 class="mb-4">Students</h2>
 <!-- Button trigg0er modal -->
 <button type="button" class="btn btn-info" data-toggle="modal" data-target="#addstudentsanamodal">
  Add Students
  </button>
  <br><br>
  <br><br>
   <!-- Add exam Modal -->
     <!-- <meta name="csrf-token" content="{{ csrf_token() }}">    --> 
     <table class="table">
    <thead>
      <tr>
        <th scope="col">S.N</th>
        <th scope="col">Exam Name</th>
        <th scope="col">Marks /Q.</th>     
        <th scope="col">Total Marks</th>     
        <th scope="col">Edit</th>     
      </tr>
    </thead>
    <tbody>

        @if(  count($exams) > 0 )
            @php $x=1; @endphp
                @foreach($exams as $exam)
                    <tr> 
                         <td>{{ $x++ }}</td>
                        <td>{{ $exam->exam_name }}</td>
                        <td>{{ $exam->marks }}</td>
                        <td>{{ count($exam->getQnaExam) * $exam->marks }}</td>
                        <td>
                           <button class="btn btn-primary editmarks" data-id="{{ $exam->id }}" data-marks="{{ $exam->marks }}" data-totleq="{{ count($exam->getQnaExam) }}" data-toggle="modal" data-target="#editMarksModal">Edit</button> 
                        </td>
                    </tr>
                @endforeach

        @else
                <tr>
                    <td colspan="5">Exam Not Added! </td>
                </tr>
        @endif

         
    </tbody>
  </table>

  <br><br>

  <form id="update_marks" >
    @csrf
     <div class="modal fade" id="editMarksModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Update Marks</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
                <div class="row">
                    <div class="col-sm-3">
                        <label for="totle marks">Marks/Q</label>
                    </div>
                    <div class="col-sm-6">
                        <input type="hidden" name="marks_exam_id" id="marks_exam_id" > 
                        <input type="text" 
                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  

                        name="marks"placeholder="Enter Marks/Q" id ="marks" required> 
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        <label for="totle marks">Totle Marks</label>
                    </div>
                    <div class="col-sm-6">
                         <input type="text"  placeholder="Totle Marks" id="tmarks" disabled > 
                    </div>
                </div>
          </div>

          <div class="modal-footer"> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update </button>
          </div>
        </div>
      </div>
    </div>
  </form>


  <script>
    $(document).ready(function(){
        var totleqna = 0
        $(".editmarks").click(function(){
            var exam_id = $(this).attr("data-id");
            var marks = $(this).attr("data-marks");
            var totleq = $(this).attr("data-totleq");


            $("#marks").val(marks);
            $("#marks_exam_id").val(exam_id);
            $("#tmarks").val((marks*totleq).toFixed(1));
            
            totleqna = totleq;
        });

        $("#marks").keyup(function(){
            $("#tmarks").val(($(this).val()*totleqna).toFixed(1));

        });

        $("#update_marks").submit(function(e){
            e.preventDefault();
            
            var formData = $(this).serialize();

            $.ajax({
                url: " {{ route('updateMarks')}}",
                type: "POST",
                data:formData,
                success:function(data){
                    if(data.success = true){
                        location.reload()
                    }else{
                        alert(data.msg)
                    }
                }
            });





        });


    });
  </script>




 
@endsection