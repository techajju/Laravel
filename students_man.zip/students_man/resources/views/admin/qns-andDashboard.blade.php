@extends('layouts/admin-index')
@section('admin_work')

<h2 class="mb-4">Q & A</h2>
 <!-- Button trigg0er modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addqnamodal">
   Add Q & A
  </button>
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#importanamodal">
  Import Q & A
  </button>
  <br><br>
   <!-- Add exam Modal -->
     <!-- <meta name="csrf-token" content="{{ csrf_token() }}">    --> 
     <table class="table">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Question</th>
        <th scope="col">Answers</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
     
      </tr>
    </thead>
    <tbody>
       @if(count($questions) > 0)
          @foreach ($questions as $question)
          <tr>
              <td>{{$question->id}}</td> 
              <td>{{$question->question}}</td> 
              <td>
                  <a herf="#"  class="ansButton" data-id="{{$question->id}}" data-toggle="modal"data-target="#viewans">See Answers</a>  
                </td> 
                
                <td>
                  <button   class="btn btn-info edit-btn edit_button" data-id="{{$question->id}}"  data-toggle="modal"data-target="#editQuestion">Edit</button>  
                </td>  
                
                <td>
                    <button class="btn btn-danger delet-btn delete_button_question" data-id="{{$question->id}}" data-toggle="modal"data-target="#deleteQuestion">Delete</button>      
            </td>
          </tr>    
          @endforeach
       @else
       <tr>
         <td aria-colspan="6"> No exam found !</td>
        </tr>
       @endif
    </tbody>
  </table>

<!-- add question models box -->
    <form id="addqna" >
     <div class="modal fade" id="addqnamodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Add Q & A</h5>
            <button class="addans">Add Answers</button>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
            <div class="modal-body addModelBody">
                <div class="row">
                  <div class="col">
                  @csrf              
                    <input type="text" name="quetion_name">
                  </div>
                </div>
            </div>
          <div class="modal-footer">
            <p class="error"></p> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add Q & A</button>
          </div>
        </div>
     </div>
    </div>
</form>
<!-- add QnA end -->
<!-- import Question and answers -->
<!-- add question models box -->
<form id="importqna" enctype="multipart/form-data">
     <div class="modal fade" id="importanamodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Import Q & A</h5>
          
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
            <div class="modal-body ">
                <div class="row">
                  <div class="col">
                  @csrf              
                    <input type="file" name="file" id="fileUpload" required accept=".csv, application/vnd/openxmlformets-offecdocument.spreadsheetml.sheet ,application/vnd.ms.excel"> 
                </div>
                </div>
            </div>
          <div class="modal-footer">
            <p class="error"></p> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-info">Import Q & A</button>
          </div>
        </div>
     </div>
    </div>
</form>

<!-- /import Question and answers --> 

<!-- show answer popup models -->

<form id="Viewans" >
    @csrf
     <div class="modal fade" id="viewans" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">See Answers</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
            <div class="modal-body">

            <table class="table">     
              <thead>
                <tr>
                  <th scope="col">ID</th> 
                  <th scope="col">Answers</th>
                  <th scope="col">Result</th> 
                </tr>
              </thead>
              <tbody class="showanswers">
                  
              </tbody>
           </table>


            </div>
          <div class="modal-footer"> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update Answser</button>
          </div>
        </div>
      </div>
    </div>
  </form> 

  <!-- /show answer popup models -->
  <!--  --> 
 
<!--  -->
<form id="editqna" >
    @csrf
      <div class="modal fade" id="editQuestion" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLongTitle">Edit Question</h5>
              <button  class="btn btn-success"id="addeditans">Add Answers</button>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body editModleAnswers">            
            <div class="row">
                    <div class="col">
                      @csrf
                          <input type="hidden" name="question_id" id="quetion_id">
                          <input type="text" name="quetion_name" id="quetion_name">
                    </div>
                  </div>
            </div>

            <div class="modal-footer"> 
              <p class="editerror"></p>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Update Question</button>
            </div>
          </div>
        </div>
      </div>
  </form>
   
  <!-- Delete Exam Modal -->
  <form id="deleteqestions">
    @csrf
     <div class="modal fade" id="deleteQuestion" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Delete Question</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <h6>Are you soure you want delete this Question</h6>
            <input type="hidden" id="deleteQuestionHidden" value=""  name="id">
            
           </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-danger">Delete</button>
          </div>
        </div>
      </div>
    </div>
  </form>
  <br><br>
 

<script>
  $(document).ready(function(){ 
    var html = '';
    //add questions
    $("#addqna").submit(function(event){
        event.preventDefault();
      if($(".answars").length < 2){
        $(".error").text("Please and minimum two answers")
        setTimeout(function(){
          $(".error").text("")
        },3000); 

      }else{ 

        var checkIsCorrect = false;
        //var  ansCheckBox = $(".is_correct").length;
        for(let i = 0; i < $(".is_correct").length; i++ ){
          if( $(".is_correct:eq("+i+")").prop('checked') == true ){
            checkIsCorrect = true;
            $(".is_correct:eq("+i+")").val( $(".is_correct:eq("+i+")").next().find('input').val());
          }
        }
 
        if(checkIsCorrect){
          var formData = $(this).serialize();
           $.ajax({
            url:"{{ route('addqna_form_action') }}",
            type:"POST",
            data:formData,
              success:function(data){     
                //console.log(data); 
                if(data.success == true){
                  location.reload();
                }else{
                 // alert(data.msg);
                 location.reload();
                }
            }
          });

        }else{  
          $(".error").text("Please choose anyone answer");
        setTimeout(function(){
          $(".error").text("")
        },3000); 
        }
      }
    });

  });
//add ans
$(".addans").click(function() {

if ($(".answars").length >= 6) {
    $(".error").text("you can add only 6 answers")
    setTimeout(function() {
        $(".error").text("")
    }, 3000);

} else {
    html = `<div class="row answars">
          <input type="radio" class="is_correct" name="is_correct">
            <div class="col">
                  <input type="text" name="ans_name[]" id="ans_name">
            </div>
          <button class="btn btn-danger removebtn">Remove</button>
      </div>`;
    $(".addModelBody").append(html);
}

});

$(document).on("click", ".removebtn", function() {
$(this).parent().remove();
});

$(".ansButton").click(function() {
var questions = @json($questions); //all question data here

var qid = $(this).attr('data-id');
var html = '';
//console.log(questions);
for (let i = 0; i < questions.length; i++) {
    //console.table(questions[i]['id']) // question id 
    //console.table(questions[i]['answers']);

    var answersLength = questions[i]['answer'].length;

   // console.log(answersLength)
    if (questions[i]['id'] == qid) {

        for (let j = 0; j < answersLength; j++) {
            let is_correct2 = "No";

            if (questions[i]['answer'][j]['is_correct'] == 1) {
                is_correct2 = "Yes";
            }

            html += `
      <tr>
        <td>` + (j + 1) + `</td>
        <td>` + questions[i]['answer'][j]['answer'] + `</td>
        <td>` + is_correct2 + `</td>
      </tr>`;

        }
        break;

    }
}
$('.showanswers').html(html);

});

//edit update answers
var html = '';
$("#addeditans").click(function() {

if ($(".editanswars").length >= 6) {
    $(".editerror").text("you can add only 6 answers")
    setTimeout(function() {
        $(".editerror").text("")
    }, 3000);

} else {
    html = `<div class="row editanswars">
        <input type="radio" class="edit_is_correct" name="is_correct">
          <div class="col">
                <input type="text" name="new_ans_name[]" id="new_ans_name" requird >
          </div>
        <button class="btn btn-danger removebtn">Remove</button>
    </div>`;
    $(".editModleAnswers").append(html);

}
});


$('.edit_button').click(function()
{
 var qid = $(this).attr('data-id');

 $.ajax({
    url: "{{ route('get-qna-details-action') }}",
    type: "GET",
    data:{qid: qid},
    success: function(data) {
//console.log(data);
        var qnadata = data.data[0];

      console.log(qnadata )

        $('#quetion_id').val(qnadata['id']);
        $('#quetion_name').val(qnadata['question']);
        $('.editanswars').remove();

        var html = '';

        for (let i = 0; i < qnadata['answer'].length; i++) {
            var checked = '';
            if (qnadata['answer'][i]['is_correct'] == 1) {
                checked = 'checked';
        }

            html += `<div class="row  editanswars">
                            <input type="radio" class="edit_is_correct" name="is_correct" ` + checked + `>
                              <div class="col">
                                    <input type="text" name="ans_name[` + qnadata['answer'][i]['id'] + `]" 
                                    value="` + qnadata['answer'][i]['answer'] + `"  required>
                              </div>
                            <button class="btn btn-danger removebtn removeAnswers" data-id="` + qnadata['answer'][i]['id'] + `">Remove</button>
                        </div>  
                    `;
            } 

        $(".editModleAnswers").append(html);

    }

});

});

$("#editqna").submit(function(event) {
  event.preventDefault();
if ($(".editanswars").length < 2) {
    $(".editerror").text("Please and minimum two answers")
    setTimeout(function() {
        $(".editerror").text("")
    }, 3000);

} else { 

    var checkIsCorrect = false;
    //var  ansCheckBox = $(".is_correct").length;
    for (let i = 0; i < $(".edit_is_correct").length; i++) {
        if ($(".edit_is_correct:eq(" + i + ")").prop('checked') == true) {
            checkIsCorrect = true;
            $(".edit_is_correct:eq(" + i + ")").val($(".edit_is_correct:eq(" + i + ")").next().find('input').val());
        }
    }
    
    //console.log(checkIsCorrect)
    if (checkIsCorrect) {
        var editformData = $(this).serialize();
          console.table(editformData);
        $.ajax({
            url: "{{ route('updateAnsAction') }}",
            type: "POST",
            data: editformData,
            success: function(data) {
                console.log(data); 
                if (data.success == true) {
                    location.reload();
                } else {
                    alert(data.msg);
                }
            }
        });
 
    } else {
        $(".editerror").text(" error Please choose anyone answer ");
        setTimeout(function() {
            $(".editerror").text("")
        }, 3000);
    }
}
});


//remvoe answers

$(document).on('click', '.removeAnswers', function()
{
 
 var ansId = $(this).attr("data-id");
  $.ajax({
      url: "{{ route('deleteAns') }}",
      type: "GET",
      data: { id: ansId },
      success: function(data) {
          if (data.success == true) {
              console.log(data.msg);
              alert(data.msg)
          } else {
              alert(data.msg);
          }
      }

  });

});

// delete questions
$('.delete_button_question').click(function(){  

var q_id = $(this).attr("data-id");

   $("#deleteQuestionHidden").val(q_id); 
   $("#deleteqestions").submit(function(e) { 
     e.preventDefault();

   var formdata = $(this).serialize();
    
  $.ajax({ 
  url: "{{ route('delete_question') }}",
  type: "POST",
  data: formdata,
  success: function(data) {
    console.log(data)
      if (data.success == true) {
        location.reload();
          console.log(data.msg);
      } else {
          alert(data.msg);
      }
  }

  });
  });
});


  //Import Question and ans

  $("#importqna").submit(function(e) { 
     e.preventDefault();

        let formData = new FormData();
        formData.append("file",fileUpload.files[0]);

        $.ajaxSetup({
          headers:{
            "X-CSRF-TOKEN":"{{ csrf_token() }}"
          }
        });

        
          $.ajax({ 
            url: "{{ route('importQnA') }}",
            type: "POST",
            data: formData,
            processData:false,
            contentType:false,
            success: function(data) {
              //console.log(data)
                if (data.success == true) {
                  location.reload();
                    console.log(data.msg);
                } else {
                    alert(data.msg);
                }
            }
            
          });
  });



</script>

@endsection