@extends('layouts/admin-index')
@section('admin_work')

<h2 class="mb-4">Students Exam Review</h2>
 <!-- Button trigg0er modal -->
 
   
   <!-- Add exam Modal -->
     <!-- <meta name="csrf-token" content="{{ csrf_token() }}">    --> 
     <table class="table">
    <thead>
      <tr>
        <th scope="col">S.N</th>
        <th scope="col">Name</th>
        <th scope="col">Exam Name</th>     
        <th scope="col">Status</th>     
        <th scope="col">Review</th>     
      </tr>
    </thead>
    <tbody>
       @if(count($attempts) > 0)
            <?php $row = 1; ?>
          @foreach ($attempts as $attempt)
          <tr>
              <td>{{$row}}</td> 
              <td>{{$attempt->user->name}}</td>   
              <td>{{$attempt->exam->exam_name}}</td> 
              <td>
                @if($attempt->status == 0)
                    <span style="color:red">Pending</span>
                 @else
                    <span style="color:green">Approved</span>
                @endif 
              </td>  
              <td>
                @if($attempt->status == 0)
                    <span style="color:red"><a href="#" class="review-approve" data-id ="{{ $attempt->id }}"data-toggle="modal" data-target="#review_examModal">Review & Approve</a></span>
                 @else
                    <span style="color:green">Complete</span>
                @endif 
              </td>  
              
          </tr>  
          <?php $row++; ?>  
          @endforeach 
       @else
       <tr>
         <td colspan="5"> students Exams not attempt !</td>
        </tr>
       @endif
    </tbody>
  </table>
 
  <br><br>

  <form id="review_exam" >
    @csrf
     <div class="modal fade" id="review_examModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Review Exam</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <input type="hidden" name="attempt_id" id="attempt_ids"> 
            <div class="modal-body review_body">
                Loading ...
            </div>

          <div class="modal-footer"> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Approved </button>
          </div>
        </div>
      </div>
    </div>
  </form>

<br><br>

<script>
$(document).ready(function(){
 
$(".review-approve").click(function(){

    var id = $(this).attr('data-id');
    
     var dataid = $('#attempt_ids').val(id); 
    
    $.ajax({
      url: "{{route('get_qna_reviewed')}}",
      type: "GET",
      data: {attempt_id : id}, 
      success: function(data){  

       //console.log(data);
         var html = '';  
        if(data.success == true){
          var data =  data.data;
          //console.log(data)
                if(data.length > 0){ 
                    for(let i=0; i< data.length; i++){
                      let = isCorrect = "<span style='color: red;' class='fa fa-close'> </span>";
                      if(data[i]['answers']['is_correct'] == 1){
                         isCorrect = "<span style='color: green;' class='fa fa-check'> </span>";

                      }
                      let annswers = data[i]['answers']['answer']

                        html += `
                                <div class="row">
                                  <div class="col-sm-12">
                                    <h6>Q(`+(i+1)+`).`+data[i]['question']['question']+`</h6>
                                      <p>Ans :-`+annswers+` `+isCorrect+` </p>
                                  <div>
                                <div>
                                `;
                    }
              } else{
                    html +=`<p> This exam not attempt student</p>
                    <p>if you are approve this exam student is fail</p>
                    ` ;

              }   
        }else{
          //console.log(data.msg)
          html += '<p>Having some server issue !</p>';
        } 

         $('.review_body').html(html);  

      } 
      
    });

  });

// approved exam
$("#review_exam").submit(function(e){
    e.preventDefault();

 var formData =  $(this).serialize();
 
 $.ajax({
  url: "{{  route('approved_qna')}}",
  type:"POST",
  data: formData,
  success: function(data){  
    console.log(data)
      if(data.success == true){
          location.reload();
      }else{
        alert(data.msg);
      }
  }


 });

});


});
  
</script>


@endsection