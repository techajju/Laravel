<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Exam;
use Illuminate\Support\Facades\Hash;

use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\Session;
use App\Models\PasswordRest;
use Mail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Carbon;
use App\Models\Subject;



class AuothController extends Controller
{
   public function loadRegister()
    {
        if(Auth::user() && Auth::user()->is_admin == 1){
        
            return redirect('/admin/dashboard');
        
        }elseif(Auth::user() && Auth::user()->is_admin == 0){
           
            return redirect('/dashboard'); 
        
        }
        return view('register');
    }

    function loadLogin()
    {
        if(Auth::user() && Auth::user()->is_admin == 1){
        
            return redirect('/admin/dashboard');
        
        }elseif(Auth::user() && Auth::user()->is_admin == 0){
           
            return redirect('/dashboard'); 
        
        }
        return view('login');
    }

    function studentRegister(Request $request )
    {
        $request->validate([
            'name' => 'string|required|min:2',
            'email' => 'string|email|required|max:100|unique:users',
            'password' => 'string|required|confirmed|min:6',
        ]);

         $user = new User();
         $user->name = $request->name;
         $user->email = $request->email;
         $user->password = Hash::make($request->password);

        $user->save();
        return back()->with('success', 'Registeration Successfully');

    }

    // Login form Function

     public function userLogin( Request  $request)
    {
        $request->validate([
            'email' => 'string|email|required',
            'password' => 'string|required',
        ]);
        
        $userCreadencial = $request->only('email','password'); 
        
        if(Auth::attempt($userCreadencial)){ 
             if(Auth::user()->is_admin == 1)
            {
                  return redirect('/admin/dashboard');
            }
            else
            {
                  return redirect('/dashboard');
            }

        }
        else
        {
            return back()->with('error','Username & Password is incorrect');

        }
        
    }

    public function studentDashboard()
    {
       $exams =  Exam::with('subject')->orderBy('date')->get();
        return view('students.dashboard',['exams'=>$exams]);
    }


    public function adminDashboard()
    {
        $subjects = Subject::all();
        return view('admin.dashboard', compact('subjects'));
    }

    public function logout( Request $request )
    {
        $request->session()->flush();
        Auth::logout();
   
        return redirect('/'); 
    }


    public function forgetPasswordLoad()
    {
       return view('forget-password');
    }

    public function forgetPasswordLoadForm(Request $request)
    {
        try{

            $user = User::where('email', $request->email)->get(); // check usertable email

             if(count($user) > 0){
                //dd($user);
               $token = Str::random(40); 
               
               $domain = URL::to('/');      
                         
               $url = $domain.'/reset-password?token='.$token;
                


                $data['url'] = $url;
                $data['email'] = $request->email;
                $data['title'] = 'password Reset';
                $data['body'] = 'Plese click on blow link to reset passsword';
                
               /*  Mail::send('forgetPasswordMail', $data, function ($message) {
                    $message->from('john@johndoe.com', 'John Doe');
                    $message->sender('john@johndoe.com', 'John Doe');
                    $message->to('john@johndoe.com', 'John Doe');
                    $message->cc('john@johndoe.com', 'John Doe');
                    $message->bcc('john@johndoe.com', 'John Doe'); 
                    $message->subject('Subject');
                    $message->priority(3); 
                }); */
                Mail::send('forgetPasswordMail',['data'=>$data],function($message) use($data){
                    
                    $message->to($data['email'])->subject($data['title']);
                }); 

                
                $datetitme = Carbon::now()->format('Y-m-d H:i:s');
                PasswordRest::updateOrCreate(
                    ['email'=> $request->email] ,
                    [
                        'email' => $request->email,
                        'token' => $token,
                        'created_at' => $datetitme,

                    ]
                    );
                    return back()->with('success', 'Plese check you mail to reset your password');
                    
            }else{
                return back()->with('error', 'Email Is Not Exists');
            }

        }catch(\Exception $e){
            return back()->with('error', $e->getMessage());
        }

    }

    public function resetPasswordLoad( Request $request)
    {
        $restDataToken = PasswordRest::where('token',$request->token)->get();

        if(isset($request->token) && count($restDataToken) > 0){
            $user = User::where('email',$restDataToken[0]['email'])->get();
       
            return view('/reset-password', compact('user'));
          
        }
        else
        {
            return view('404');
        }

    }

        public function resetPasswordLoadForm(Request $request)
        {
            $request->validate([
                'password' => 'string|required|confirmed|min:6',
            ]);

            $user = User::find($request->id);
            $user->password = Hash::make($request->password);
            $user->save();

            PasswordRest::where('email',$user->email)->delete(); // deleteing here token

            return "<h2>your password hass been successfully reset<h2><br><a href ='/login'>Login<a>";
        }







}
