<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subject;
use App\Models\Exam;
use App\Models\ExamAnswers;
use App\Models\ExamAttempt;
use App\Models\Question;
use App\Models\Answer;
use App\Models\QnAExamsModel;

use App\Imports\QnaImort;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\URL;


class AdminController extends Controller
{
        public function addSubject( Request $request)
        {
             //return $request->all();

             try{ 
                Subject::insert([
                         'subject' => $request->sub_name,
                ]);

                     return response()->json(['success' => true, 'msg' => "subject add  successfully"]);

             }catch(\Exception $e){
                
                return response()->json(['success' => false, 'msg' => $e->getMessage()]);

             }

        }

        //edit subject
        public function editSubject( Request $request)
        {
             //return $request->all();

             try{ 
        
                $subject_id = Subject::find($request->id);
                $subject_id->subject = $request->sub_name_edit;
                $subject_id->save();

                     return response()->json(['success' => true, 'msg' => "subject edit  successfully"]);

             }catch(\Exception $e){
                
                return response()->json(['success' => false, 'msg' => $e->getMessage()]);

             }

        }

        //Delete subject
        public function deleteSubject( Request $request)
        {
                try{ 
                        $subject_id = Subject::where('id', $request->id)->delete();         
                             return response()->json(['success' => true, 'msg' => "Subject Delete  Successfully"]);
                     }catch(\Exception $e){
                        return response()->json(['success' => false, 'msg' => $e->getMessage()]);
        
                     }
        }

        //exam system
        public function examDashboard()
        {
          
         $subjects = Subject::all();
         $exams = Exam::with('subject')->get();
         return view('admin.examDashboard',['subjects'=>$subjects ,'exams'=>$exams]);
        }

        public function addexam( Request $request)
        {
           
           //return $request->all();
           try{ 
                $entrands_id = uniqid("exam_id");
               Exam::insert([
                         'exam_name' => $request->exam_name,
                         'subject_id' => $request->subject_id,
                         'date' => $request->date,
                         'time' => $request->time,
                         'attemt' => $request->attempt,
                         'entrance_id' => $entrands_id,
                ]);  
                     return response()->json(['success' => true, 'msg' => "Add Exam successfully"]);

             }catch(\Exception $e){
                
                return response()->json(['success' => false, 'msg' => $e->getMessage()]);

             }

        }

        public function get_exam_deltails($id)
        {

         try{ 
            $examDetals = Exam::where('id',$id)->get();
            return response()->json(['success' => true, 'data' => $examDetals]);
          }catch(\Exception $e){
             
             return response()->json(['success' => false, 'msg' => $e->getMessage()]);

          }


        }


          public function editExam( Request $request)
        {

             try{ 
                $exam_id = Exam::find($request->exam_id);
                $exam_id->exam_name	 = $request->exam_name;
                $exam_id->subject_id = $request->subject_id;
                $exam_id->date = $request->date;
                $exam_id->time = $request->time;
                $exam_id->attemt = $request->attempt;
                $exam_id->save(); 

                     return response()->json(['success' => true, 'msg' => "exam update  successfully"]);

             }catch(\Exception $e){
                
                return response()->json(['success' => false, 'msg' => $e->getMessage()]);
             }
        } 
        

        public function deleteExam( Request $request)
        {
                try{ 
                        $deleteExamId = Exam::where('id', $request->id)->delete();  

                             return response()->json(['success' => true, 'msg' => "Exam Delete  Successfully"]); 

                     }catch(\Exception $e){
                        
                        return response()->json(['success' => false, 'msg' => $e->getMessage()]);
        
                     }

        }


       /**Q and A***/ 
       public function qnsAndDashboard(){
         $questions = Question::with('answer')->get();
         return view('admin.qns-andDashboard',compact('questions'));
       }

       //add q and a
       public function addqna(Request $request)
       {

        // return response()->json($request->all());

        try {  
           $quetion_id = Question::insertGetId([
               "question" => $request->quetion_name
            ]);

           $answers = $request->ans_name;
           
            foreach($request->ans_name as $answer ){ 
              
               $is_correct = 0;
               
               if($request->is_correct == $answer){ 
                  $is_correct = 1;
               }
 
                 Answer::insert([
                  "question_id" => $quetion_id,
                  "answer" => $answer,
                  "is_correct" => $is_correct,  
               ]);
            
            }
            return response()->json(['success' => true, 'msg' => "question added  Successfully"]); 
              
         } catch(\Exception $e){
         
         return response()->json(['success' => false, 'msg' => $e->getMessage()]);

         }

       }

   //getAnswers Details

public function getQnADetails(Request $request){
   
   // return $qna =  Question::where('id',$request->qid)->with('answer')->get();
    
   $qna =  Question::where('id',$request->qid)->with('answer')->get();
   return response()->json(['data'=>$qna]);

}  

//delete answers
public function deleteAns(Request $request)
{

    Answer::where('id',$request->id)->delete();
   return response()->json(['success'=>true, 'msg'=>'Answers Deleted successfully']);

}
// update answers

public function updateAns(Request $request)
{

//   return print_r($request->question_id);

   //return response()->json($request->all()); 
     try {  
      Question::where('id', $request->question_id)->update(['question' => $request->quetion_name]);

      //$answers = $request->ans_name; 

      //add old answeers
      if(isset($request->ans_name)){  
         foreach($request->ans_name as $key => $answer_val ){ 
         
               $is_correct = 0;
               if($request->is_correct == $answer_val){ 
                  $is_correct = 1;
               }   

            Answer::where('id', $key)->update([
               'question_id' => $request->question_id,
               'answer'=> $answer_val,
               'is_correct'=> $is_correct,

            ]);

         }
      }

         //add new answers

         if(isset($request->new_ans_name)){

            foreach($request->new_ans_name as $new_key => $new_answer_val ){ 
            
                 $is_correct = 0;
               
               if($request->is_correct == $new_answer_val){ 
                  $is_correct = 1;
               }   
   
               Answer::insert([ 
                  'question_id' => $request->question_id,
                  'answer'=> $new_answer_val,
                  'is_correct'=> $is_correct,
                  ]); 

                  }
               } 
 
            return response()->json(['success' => true, 'msg' => "Q and A udpated  Successfully"]); 
               
      } catch(\Exception $e){
         
         return response()->json(['success' => false, 'msg' => $e->getMessage()]);

      } 
   
}  

public function delete_question_callback(Request $request)
{

   try{ 
        Question::where('id', $request->id)->delete();  
        Answer::where('question_id', $request->id)->delete();   
           return response()->json(['success' => true, 'msg' => "Questiion Delete  Successfully"]);  
   }catch(\Exception $e){
      return response()->json(['success' => false, 'msg' => $e->getMessage()]);
   }

}

//Import Q and A

   public function importQnA( Request $request){

      try{
         Excel::import(new QnaImort, $request->file('file') );
         return response()->json(['success' => true, 'msg' => "Imports QnA  Successfully"]);  

      }catch(\Exception $e){
         return response()->json(['success' => false, 'msg' => $e->getMessage()]);
      }

      
   }


   //Get and Select Question  for Exam

   public function getQuestionsForExams(  Request $request){
      try {
         
         $questions = Question::all();
         if(count($questions) > 0 ){
            $data = [];
            $counter = 0;
   
            foreach($questions as $question){
               $qnaExam = QnAExamsModel::where(['exam_id'=>$request->exam_id, 'question_id' =>$request->id])->get();
   
                  if(count($qnaExam) == 0){
                     $data[$counter]['id'] = $question->id;
                     $data[$counter]['questions'] = $question->question;
                     $counter++;
                  }  
               }
               return response()->json(['success' =>true , 'msg' =>'Question data!!','data'=>$data]);
            
            }else{
               
               return response()->json(['success' =>false , 'msg' =>'Question not Found !!']);      
            }
   


      }catch(\Exception $e){
         return response()->json(['success' => false, 'msg' => $e->getMessage()]);
      } 
   }   

   //insert Question and exam id in qna_exams table 
   public function addExamQnA( Request $request){

               try {

                 // return print_r($request->questions_ids); 
                  if(isset($request->questions_ids)){
                     foreach($request->questions_ids as $qid){
                        QnAExamsModel::insert([
                           'exam_id' => $request->exam_id,
                           'question_id' => $qid
                        ]);
                     }
                  }

                   return response()->json(['success' =>true , 'msg' =>'Question  Added  In Exam !!']);       
                  }catch(\Exception $e){
                     return response()->json(['success' => false, 'msg' => $e->getMessage()]);
                  } 


   }

   public function getExamQuestion( Request $request){
      try {
          
         $data = QnAExamsModel::where('exam_id', $request->exam_id)->with('question')->get();
         
         return response()->json(['success' =>true , 'msg' =>'Question Details !!', 'data' => $data]);      
      }catch(\Exception $e){
         return response()->json(['success' => false, 'msg' => $e->getMessage()]);
      }


   }
   public function deleteExamQuestion( Request $request){
      try {

         QnAExamsModel::where('id', $request->id)->delete();
         return response()->json(['success' =>true , 'msg' =>'Question Delete !!']);      

      }catch(\Exception $e){
         return response()->json(['success' => false, 'msg' => $e->getMessage()]);
      }


   }

   public function loadMarks(){

      $exams = Exam::with('getQnaExam')->get();
      return view('admin.marksDashbord',compact('exams')) ;

   }

   public function updateMarks( Request $request){
         try {
               $updatemarks = Exam::where('id',$request->marks_exam_id)->update([
                  'marks' => $request->marks,
               ]);

            return response()->json(['success' =>true , 'msg' =>'Marks Updated !']);      

         }catch(\Exception $e){
            return response()->json(['success' => false, 'msg' => $e->getMessage()]);
         }

   }

   public function exam_review()
   { 
      $attempts = ExamAttempt::with(['user','exam'])->orderBy('id')->get();
      return view('admin.exam-reviews', compact('attempts')); 
   }

   public function get_qna_reviewed( Request $request)
   {   
      try {
         $attemptdata = ExamAnswers::where('attempt_id', $request->attempt_id)->with(['question','answers'])->get();
         
          return response()->json(['success' => true, 'data' => $attemptdata]);

      }catch(\Exception $e){
         return response()->json(['success' => false, 'msg' => $e->getMessage()]);
      }

   }


   public function approved_qna( Request $request)
   {   
      try {
       $attemptId = $request->attempt_id;  
          
        $ExamData  = ExamAttempt::where('id', $attemptId)->with(['exam','user'])->get();
         $marks = $ExamData[0]['exam']['marks'];

         $attemptData = ExamAnswers::where('attempt_id', $attemptId)->with('answers')->get();
         $totleMarks = 0;
         
             if(count($attemptData) > 0){
            foreach($attemptData as $attempt){
               if($attempt->answers->is_correct == 1){
                     $totleMarks *= $marks; 

               }
            }
         }   


          $dataupdate =  ExamAttempt::where('id',$attemptId)->update([
               'status' => '1',
               'marks' => $totleMarks,
         ]);  

         $url = URL::to('/');

         $data['url'] = $url.'/results';
         $data['name'] = $ExamData[0]['user']['name'];
         $data['email'] = $ExamData[0]['user']['email'];
         $data['exam_name'] = $ExamData[0]['exam']['exam_name'];
         $data['title'] = $ExamData[0]['exam']['exam_name'].'Result';

         Mail::send('result-mail',['data' => $data], function($message) use($data){
            $message->to($data['email'])->subject($data['title']);
         });

 
          return response()->json(['success' => true, 'msg' => "exam Approved" ,'data' => $dataupdate]);

      }catch(\Exception $e){
         return response()->json(['success' => false, 'msg' => $e->getMessage()]);
      }

   }








}




