<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request; 
use App\Models\Subject;
use App\Models\Exam;
use App\Models\Question;
use App\Models\Answer;
use App\Models\User; 

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\URL;
use Mail;


class StudetsController extends Controller
{
    function studentsDashboard(){

       $students =  User::where('is_admin',0)->get();
        return view('admin.studentsDashboard',compact('students'));

    }

    function addStudets(Request $request){
        
        try{ 
           $password =  Str::random(8);   

            User::insert([
                "name" => $request->name, 
                "email" => $request->email, 
                "password" => Hash::make($password)
            ]);

            $url = URL::to('/');

            $data['url'] = $url;
            $data['name'] = $request->name;
            $data['email'] = $request->email;
            $data['password'] = $password;
            $data['title'] = "Register Student Online Examination";

            Mail::send('registeratinMail',['data'=>$data],function($message) use ($data){
                $message->to($data['email'])->subject($data['title']);
            });

            return response()->json(['success' => true, 'msg' => "Student Created  Successfully"]);  
        }catch(\Exception $e){
            return response()->json(['success' => false, 'msg' => $e->getMessage()]);
        }

    }


    //edit students

    function eidtStudets(Request $request){
        
        try{ 
            
            $user = User::find($request->id); 
            
            $user->name = $request->name;
            $user->email = $request->email;
            $user->save();
             


            $url = URL::to('/');

            $data['url'] = $url;
            $data['name'] = $request->name;
            $data['email'] = $request->email; 
            $data['title'] = "Updateed Student profile";

            Mail::send('updateProfileMail',['data'=>$data],function($message) use ($data){
                $message->to($data['email'])->subject($data['title']);
            });

            return response()->json(['success' => true, 'msg' => "Student Updated  Successfully"]);  
        }catch(\Exception $e){
            return response()->json(['success' => false, 'msg' => $e->getMessage()]);
        }

    }
    function delete_students_callback(Request $request){
        
        try{ 
             User::where('id', $request->id)->delete();  

            return response()->json(['success' => true, 'msg' => "Student Updated  Successfully"]);  
        }catch(\Exception $e){
            return response()->json(['success' => false, 'msg' => $e->getMessage()]);
        }

    }


}
