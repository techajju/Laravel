<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Exam;
use App\Models\QnAExamsModel;
use App\Models\ExamAttempt;
use App\Models\ExamAnswers; 
use Illuminate\Support\Facades\Auth;

class ExamController extends Controller
{
    

    public function studentExamDashboard($id)
    {
        $qnaExam = Exam::where('entrance_id',$id)->with('getQnaExam')->get();
 
        if(count($qnaExam) > 0){

            $attemtCounter = ExamAttempt::where(['exam_id' => $qnaExam[0]['id'], 'user_id' => Auth()->user()->id ])->count();
            if( $attemtCounter >= $qnaExam[0]['attemt']){
                return  view('students.exam-dashboard',['success' => false, 'msg'=>'Your exam attemption has been completed','exam'=>$qnaExam]);

            } 

            if($qnaExam[0]['date'] == date('Y-m-d')){
                
                if(count($qnaExam[0]['getQnaExam']) > 0){

                    $qna = QnAExamsModel::where('exam_id',$qnaExam[0]['id'])->with('question','answars')->inRandomOrder()->get();
                    return  view('students.exam-dashboard',['success' => true,'exam'=>$qnaExam, 'qna' => $qna]);
 
                }else{

                    return  view('students.exam-dashboard',['success' => false, 'msg'=>'This exam will not avalible at the moments','exam'=>$qnaExam]);

                }
 


            }elseif($qnaExam[0]['date'] > date('Y-m-d')){
                return  view('students.exam-dashboard',['success' => false, 'msg'=>'This exam will be satrt' .$qnaExam[0]['date'],'exam'=>$qnaExam]);
            }else{
                return  view('students.exam-dashboard',['success' => false, 'msg'=>'This exam will be expired' .$qnaExam[0]['date'],'exam'=>$qnaExam]);
            } 
             
        }else{

             return view('404');
        }

    } 

        public function examSubmit( Request $request ) {
            //return $request->all();

           $attempt_id = ExamAttempt::insertGetId([
                'exam_id' => $request->exam_id,
                'user_id' => Auth::user()->id
            ]); 
            $qcount = count($request->q);
            if( $qcount > 0 ){
                    for($i = 0; $i < $qcount; $i++){
                        if(!empty($request->input('ans_'.($i+1)))){
                            ExamAnswers::insert([
                                'attempt_id' => $attempt_id,
                                'question_id' => $request->q[$i],
                                'answer_id' => request()->input('ans_'.($i+1))
                            ]);
                        }
                        
                    }
            }

            return view('thank-you');

        }


}
