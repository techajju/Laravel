<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use App\Models\ExamAttempt;
use Illuminate\Support\Str;


class Exam extends Model
{
    use HasFactory;

    protected $filleable = [
        'exam_name',
        'subject_id',
        'date',
        'time',
        'attemt', 
    ];

    protected $appends = ['attempt_counter'];
    public $count = 0;

    public function subject()
    {
        return $this->hasMany(Subject::class,'id','subject_id');
    }
    public function getQnaExam()
    {
        return $this->hasMany(QnAExamsModel::class,'exam_id','id');
    }


     
    public function getAttemptCounterAttribute(){

        return $this->count;
    }  

     public function getIdAttribute($value){

        $attemtCounter = ExamAttempt::where(['exam_id' => $value, 'user_id' => Auth()->user()->id ])->count();
        $this->count =  $attemtCounter; 

        return $value;
    } 



}

