<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuothController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\StudetsController;
use App\Http\Controllers\ExamController;

//8:31

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/register',[AuothController::class,'loadRegister']);
Route::post('/register',[AuothController::class,'studentRegister'])->name('studentRegisterFormAction');

Route::get('/login', function(){
    return redirect('/');
});

    Route::get('/',[ AuothController::class,'loadLogin']);

    Route::post('/login',[AuothController::class,'userLogin'])->name('loginForm');

    Route::get('/logout',[AuothController::class,'logout']); 
    Route::get('/forget-password',[AuothController::class,'forgetPasswordLoad']);
    Route::post('/forget-password',[AuothController::class,'forgetPasswordLoadForm'])->name('forgetPasswordLoadFormAction');
    
    Route::get('/reset-password',[AuothController::class,'resetPasswordLoad']);
    Route::post('/reset-password',[AuothController::class,'resetPasswordLoadForm'])->name('resetPasswordLoadFormAction');
    
Route::group(['middleware'=>['web','checkadmin']],function(){
    Route::get('/admin/dashboard',[AuothController::class,'AdminDashboard']);
    //subject
    Route::post('/add-subject',[AdminController::class,'addSubject'])->name('addSubject');
    Route::post('/edit-subject',[AdminController::class,'editSubject'])->name('editSubject');
    Route::post('/delete-subject',[AdminController::class,'deleteSubject'])->name('deleteSubject');
    //exam
    Route::get('/admin/exam',[AdminController::class,'examDashboard']);
    Route::post('/add-exam',[AdminController::class,'addexam'])->name('addexam');
    Route::get('/get_exam_deltails/{id}',[AdminController::class,'get_exam_deltails'])->name('get_exam_deltails');
    Route::post('/edit-exam',[AdminController::class,'editExam'])->name('editExam');
    Route::post('/delete-exam',[AdminController::class,'deleteExam'])->name('deleteExam');
    // exam Marks Route
    Route::get('/admin/marks',[AdminController::class,'loadMarks']);
    Route::post('/admin/updateMarks',[AdminController::class,'updateMarks'])->name('updateMarks');
    
    //Review Question and ans
    Route::get('/admin/exam-review',[AdminController::class,'exam_review']);
    Route::get('/get-qna-reviewed',[AdminController::class,'get_qna_reviewed'])->name('get_qna_reviewed');
    Route::post('/approved-qna',[AdminController::class,'approved_qna'])->name('approved_qna');

    
    //Q and A
    Route::get('/admin/qna-ans',[AdminController::class,'qnsAndDashboard']);
    Route::post('/add-qna-ans',[AdminController::class,'addqna'])->name('addqna_form_action');
    Route::get('/get-qna-details',[AdminController::class,'getQnADetails'])->name('get-qna-details-action');
    Route::get('/delete-ans',[AdminController::class,'deleteAns'])->name('deleteAns');
    Route::post('/delete-question',[AdminController::class,'delete_question_callback'])->name('delete_question');
    Route::post('/update-qna-ans',[AdminController::class,'updateAns'])->name('updateAnsAction');
    Route::post('/import-qna-ans',[AdminController::class,'importQnA'])->name('importQnA');
    Route::get('/get-qna',[AdminController::class,'getQuestionsForExams'])->name('getQuestionsForExams');
    Route::post('/add-questions',[AdminController::class,'addExamQnA'])->name('addExamQnA');
    Route::get('/get-exam-question',[AdminController::class,'getExamQuestion'])->name('getExamQuestion');
    Route::get('/delete-exam-question',[AdminController::class,'deleteExamQuestion'])->name('deleteExamQuestion');
    
    //students route 
    Route::get('/admin/students',[StudetsController::class,'studentsDashboard']);
    Route::post('/add-students',[StudetsController::class,'addStudets'])->name('addStudets');
    Route::post('/edit-students',[StudetsController::class,'eidtStudets'])->name('eidtStudets');
    Route::post('/delete-students',[StudetsController::class,'delete_students_callback'])->name('delete_students');

     
      
}); 
  
Route::group(['middleware'=>['web','checkstudet']],function(){
    Route::get('/dashboard',[AuothController::class,'studentDashboard']);
    Route::get('/exam/{id}',[ExamController::class,'studentExamDashboard']);
    Route::post('/exam-submit',[ExamController::class,'examSubmit'])->name('examSubmit');
}); 




