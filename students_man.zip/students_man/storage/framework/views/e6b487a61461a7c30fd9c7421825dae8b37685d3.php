
<?php $__env->startSection('admin_work'); ?>

<h2 class="mb-4">Exam</h2>
<style>
 input.question_checkbox {
    width: 100%;
}
.tablebody .table th, .table td {
    padding: 8px !important;
}
  .multiple{ 
  width: 100%;
  }
  .multiselect-dropdown-list>div {
    height: 33px !important;
    margin: 0px !important;
    padding: 0px !important;
}

</style>
 <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addexmmodal">
    Add Exam
  </button>
   <!-- Add exam Modal -->
<form id="addexam_id" >
    <?php echo csrf_field(); ?>
     <div class="modal fade" id="addexmmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Add Exam</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            
            <input type="text" id="exam_name" name ="exam_name" placeholder=" Enter Exam Name" required>
                <br><br>
            <select name="subject_id" required >
                <option value="">Select Subject</option>
                <?php if(count($subjects)> 0): ?>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->subject); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
          <br><br>
          <input type="date" id="date" name ="date"  min="{ <?php echo date('Y-m-d') ?>}" >
            <br><br>
            <input type="time" name="time">
            <br><br>
            <input type="number" min="1" name="attempt" placeholder="Enter Exam Attempt Time" required>
          </div>

          <div class="modal-footer"> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add Exam</button>
          </div>
        </div>
      </div>
    </div>
  </form>



<!-- Edit exam Modal -->
<form id="editexams" >
    <?php echo csrf_field(); ?>
     <div class="modal fade" id="editexammodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Update Exam</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
                 <input type="hidden" id="exam_id" name="exam_id">            
                 <input type="text" id="edit_exam_name" name ="exam_name"  placeholder=" Enter Exam Name" required>
                <br><br>
            <select name="subject_id" id="subject_id" required >
                <option value="">Select Subject</option>
                <?php if(count($subjects)> 0): ?>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->subject); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
          <br><br>
          <input type="date" id="edit_date" name ="date"  min="{ <?php echo date('Y-m-d') ?>}" >
            <br><br>
            <input type="time" id="edit_time" name="time">
            <br><br>
            <input type="number" min="1" name="attempt" id="attemt"placeholder="Enter Exam Attempt Time">
          </div>

          <div class="modal-footer"> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update Exam</button>
          </div>
        </div>
      </div>
    </div>
  </form>



  <!-- Delete Exam Modal -->
  <form id="deleteExams">
    <?php echo csrf_field(); ?>
     <div class="modal fade" id="deleteexammodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Delete Exams</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <h6>Are you soure you want delete this Exam</h6>
            <input type="hidden" id="deleteExamId" value=""  name="id">
           </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-danger">Delete</button>
          </div>
        </div>
      </div>
    </div>
  </form>
<!-- end -->
<!-- add question in exam --> 
<form id="addQuestionInExam">
    <?php echo csrf_field(); ?>
     <div class="modal fade" id="AddQuestionmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Add Question</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>  
          <div class="modal-body">
            <input type="hidden" name="exam_id" value=""   id="AddExamId">
            <input type="search" name="Question_Search" id="Question_Search" onkeyup='searchTable()'>
            <br><br> 
              <table class="table" id="QuestionTable">
                  <thead>
                    <th>Select</th> 
                    <th>Question</th>   
                  </thead>  
                  <tbody class="tablebody">
                    
                  </tbody> 
              </table>  
          </div>  
          <div class="modal-footer"> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add Question</button>
          </div>
        </div>
      </div>
    </div>
  </form>
<!-- /add question in exam -->
<br><br>

<!-- See question in exam -->
     <div class="modal fade" id="SeeQuestionmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>  
          <div class="modal-body">
              <table class="table" id="seeQuestionTable">
                  <thead>
                    <th>S.No</th>   
                    <th>Question</th>   
                    <th>Delete Question</th>   
                  </thead>  
                  <tbody class="seetablebody">
                    
                  </tbody> 
              </table>  
          </div>  
          <div class="modal-footer"> 
          </div>
        </div>
      </div>
    </div>
<!-- /add question in exam -->
  <table class="table">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Subject</th>
        <th scope="col">Exam Name</th>
        <th scope="col">Date</th>
        <th scope="col">Time</th> 
        <th scope="col">Attempt</th> 
        <th scope="col">Add Question</th> 
        <th scope="col">See Question</th> 
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
      </tr>
    </thead>
    <tbody>
       <?php if(count($exams) > 0): ?>
          <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td><?php echo e($exam->id); ?></td>
              <td><?php echo e($exam->exam_name); ?></td>
              <td><?php echo e($exam->subject[0]['subject']); ?></td>
              <td><?php echo e($exam->date); ?></td>
              <td><?php echo e($exam->time); ?></td>
              <td><?php echo e($exam->attemt); ?></td>
              <td>
                <a href="#" class="add_questions" data-id="<?php echo e($exam->id); ?>" data-toggle="modal"data-target="#AddQuestionmodal">Add Question</a>           
              </td>  
              <td>
                <a href="#" class="see_questions" data-id="<?php echo e($exam->id); ?>" data-toggle="modal"data-target="#SeeQuestionmodal">See Question</a>           
              </td>  
              <td>
                  <button   class="btn btn-info edit-btn edit_exam_button" data-id="<?php echo e($exam->id); ?>" data-exam="<?php echo e($exam->subject); ?>" data-toggle="modal"data-target="#editexammodal">Edit</button>  
              </td>  
              <td>
                  <button class="btn btn-danger delet-btn delete_exam_button" data-id="<?php echo e($exam->id); ?>" data-toggle="modal"data-target="#deleteexammodal">Delete</button>        
            </td>
          </tr>    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php else: ?>
       <tr>
         <td aria-colspan="6"> No exam found !</td>
        </tr>
       <?php endif; ?>
    </tbody>
  </table>



  <script>

    $(document).ready(function () {
        $('#addexam_id').submit(function(e){
                 e.preventDefault();
        var formData = $(this).serialize();
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('addexam')); ?>",
                data: formData, 
                success: function (data) {
                    if(data.success == true)
                    {
                        location.reload();
                    }
                    else
                    {
                        alert(data.msg);
                    }
                }
            });

        });        
    });

//Edit Update Exam
$(".edit_exam_button").click(function(){
    var id = $(this).attr("data-id")
        $("#exam_id").val(id);

        var url = "<?php echo e(route('get_exam_deltails','id')); ?>";
        url = url.replace('id',id);

    $.ajax({
        url:url,
        type:"GET",
        success:function(data){

            if(data.success == true)
            {
            var exam = data.data; 
            console.log(exam);
            $("#edit_exam_name").val(exam[0].exam_name)
            $("#subject_id").val(exam[0].subject_id)
            $("#edit_date").val(exam[0].date)
            $("#edit_time").val(exam[0].time)
            $("#attemt").val(exam[0].attemt)
            
           // location.reload();
          }
          else
          {
            alert(data.msg);
          } 
        }

    });

});

$('#editexams').submit(function(e){
           e.preventDefault();
        var formData = $(this).serialize();
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('editExam')); ?>",
                data: formData, 
                success: function (data) {

                    if(data.success == true)
                    {
                        location.reload();
                    }
                    else
                    {
                        alert(data.msg);
                    }
                }
            });
        });
         
        
//Delete exam 
$(".delete_exam_button").click(function(){
      var delete_id = $(this).attr("data-id") 
      $("#deleteExamId").val(delete_id);

      $("#deleteExams").submit(function(e) { 
        e.preventDefault();
       var formdata = $(this).serialize();
      $.ajax({
        url:"<?php echo e(route('deleteExam')); ?>", 
        type:'POST',
        data: formdata,
        success:function(data){
            //console.log(data);
          if(data.success == true)
          
          {
            location.reload();
          }
          else
          {
            alert(data.msg);
          } 
         }

      });
      
    });


    });

    //add question in exam

    $('.add_questions').click(function(){
      var id = $(this).attr('data-id');
      $('#AddExamId').val(id);
      
        $.ajax({
          url: "<?php echo e(route('getQuestionsForExams')); ?>",
          type: "GET",
          data:{exam_id:id},
          success: function(data){
            //console.log(data)
            if(data.success ==  true){
              var questions = data.data;            
              var html = '';
              if(questions.length > 0){ 
                for(let i=0; i<questions.length; i++){
                  html +=`
                          <tr>
                            <td> <input class="question_checkbox" type="checkbox" value="`+questions[i]['id']+`" name="questions_ids[]"></td>
                            <td>`+questions[i]['questions']+`</td>
                          </tr>
                          `;
                      }

                    }else{

                    html +=`<tr>
                            <td colspan="2"> Questions in not Aveliable!</td>
                          </tr>`;
                      }  

                    $('.tablebody').html(html);
                  }else{
                    alert(data.msg)
                  }
                }
        });
    });


    // addQna in exam
    $('#addQuestionInExam').submit(function(e){
           e.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                url: "<?php echo e(route('addExamQnA')); ?>",
                type: "POST",
                data: formData, 
                success: function (data) {
                    console.log(data);
                  if(data.success == true)
                    { 

                     location.reload();
                    
                    }else
                    {
                        alert(data.msg);
                    }
                }
            });
        });

        // see Exam  Question

        $(".see_questions").click(function(){
          var id = $(this).attr("data-id");

          $.ajax({
            url:"<?php echo e(route('getExamQuestion')); ?>",
            type: "GET",
            data:{exam_id:id},
            success:function(data){
             // console.log(data);
              var html = '';
              var questions = data.data;
              console.log(questions);
              if(questions.length > 0){
                for(let i = 0; i < questions.length; i++){
                   
                  html += `
                      <tr>
                        <td>`+(i + 1)+`</td>
                        <td>`+questions[i]['question'][0]['question']+`</td>
                        <td>
                          <button class="btn btn-danger deleteQuestion" data-id="`+questions[i]['id']+`">Delete</button>
                        </td>
                      </tr> 
                   `; 
                }
            }else{
              html += `
                      <tr>
                        <td style="color: red;">Question not available !!</td>
                      </tr> 
                  `;
            
                }
                $('.seetablebody').html(html);
          } 
          });
        });
        
  </script>





<script>
  function searchTable(){
   // QuestionTable

   var input,table,filter,tr,td,i,textvalue;

   input = document.getElementById('Question_Search');
   filter = input.value.toUpperCase();
   table = document.getElementById('QuestionTable');
   tr = table.getElementsByTagName("tr")

   for(i = 0; i < tr.length; i++){
    td = tr[i].getElementsByTagName("td")[1];
    if(td){
      textvalue = td.textContent || td.innerText;
      if(textvalue.toUpperCase().indexOf(filter) > -1){
        tr[i].style.display = "";
      }else{
        tr[i].style.display = "none";

      }

    }else{

   $('.tablebody').html('<tr><td style="color: red"> No Question  Data Found !!!</td></tr>');
   td.style.color = "red";
    }


   }
 
  }


  $(document).on('click','.deleteQuestion', function(){  
         var id = $(this).attr("data-id");
         var obj = $(this);
         $.ajax({
           url:"<?php echo e(route('deleteExamQuestion')); ?>",
           type: "GET",
           data:{id:id},
           success:function(data){
             //console.log(data);
             if(data.success == true){
               obj.parent().parent().remove();
             }else{
               alert(data.msg)
             }
           }

       });
       
     });

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\students_man\resources\views/admin/examDashboard.blade.php ENDPATH**/ ?>