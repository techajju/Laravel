<!DOCTYPE html> 
<head>
  
    <title><?php echo e($data['title']); ?></title>
</head>
<body>
    <table>
        <tr>
            <th>Name</th>
            <th><?php echo e($data['name']); ?></th> 
        </tr>
        <tr>
            <th>Email</th>
            <th><?php echo e($data['email']); ?></th>
        </tr>
        <tr>
            <th>Password</th>
            <th><?php echo e($data['password']); ?></th>
        </tr>
        
        <a href="<?php echo e($data['url']); ?>">click here to login your account</a>
        <p>Thank you!</p>
    </table>   
</body>
</html><?php /**PATH C:\xampp\htdocs\students_man\resources\views/registeratinMail.blade.php ENDPATH**/ ?>