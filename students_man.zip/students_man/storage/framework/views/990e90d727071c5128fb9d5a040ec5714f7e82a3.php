

<?php $__env->startSection('main'); ?>
    <div class="comtainer">
        <div class="text-center">
            <h2>Thanks for submit your exam, <?php echo e(Auth::user()->name); ?></h2>
            <p> we will review your exam and inform you by email</p>
            <a href="/dashboard" class="btn btn-info"> Go back</a>
        </div>
    </div>


<?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\students_man\resources\views/thank-you.blade.php ENDPATH**/ ?>