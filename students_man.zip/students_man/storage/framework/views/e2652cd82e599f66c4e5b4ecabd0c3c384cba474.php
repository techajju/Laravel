<!DOCTYPE html> 
<head>
  
    <title><?php echo e($data['title']); ?></title>
</head>
<body>
    <table>
        <tr>
            <th>Name</th>
            <th><?php echo e($data['name']); ?></th> 
        </tr>
        <tr>
            <th>Email</th>
            <th><?php echo e($data['email']); ?></th>
        </tr>
       
        <p>you can use your previous password</p>
        
        <a href="<?php echo e($data['url']); ?>">click here to login your account</a>
        <p>Thank you!</p>
    </table>   
</body>
</html><?php /**PATH C:\xampp\htdocs\students_man\resources\views/updateProfileMail.blade.php ENDPATH**/ ?>