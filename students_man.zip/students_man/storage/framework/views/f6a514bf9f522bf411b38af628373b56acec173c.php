

<?php $__env->startSection('main'); ?>
<style>
    form>span {
  color:red;
   }
    form>p {
  color:green;
   }
   .row { 
    flex-direction: column !important;
}
.row.login {
    padding: 40px;
    border: 1px solid;
    margin-top: 34px; 
    box-shadow: 0px 2px 2px 0px rgb(0 0 0 / 14%), 0px 3px 1px -2px rgb(0 0 0 / 12%), 0px 1px 5px 0px rgb(0 0 0 / 20%);
    border-radius: 8px; 
    background: #fff;
    width: 42%;
    margin: auto;
}
.container {
    margin-top: 30px;
}
h1 {
    text-align: center;
    text-decoration: underline;
}


@media only screen and (max-width: 986px) {
  .row.login { 
    width: 100%;
}
h1 { 
    font-size: 35px;
    margin-bottom: 13px;
}
}


  </style>


<div class="container">

<div class="row login">





<?php if(Session::has('error')): ?>
<p><?php echo e(Session::get('error')); ?></p>
<?php endif; ?>
<h1>Login Form</h1>
<form action="<?php echo e(route('loginForm')); ?>" method="POST">
    <?php echo csrf_field(); ?>
Email : <input type="text" name="email" id="email"><br>
<span><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
<br>
Password : <input type="text" name="password" id="pass"><br>
<span><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
 <br>
<input type="submit" class="btn btn-primary"name="login" id="login" value="Login"><br><br>
    
</form>

<a href="/forget-password">Forget Password</a>
<?php $__env->stopSection(); ?>

</div>
</div>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\students_man\resources\views/login.blade.php ENDPATH**/ ?>