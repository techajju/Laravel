
<?php $__env->startSection('admin_work'); ?>
<h1>exam</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\students_man\resources\views//admin/examDashboard.blade.php ENDPATH**/ ?>