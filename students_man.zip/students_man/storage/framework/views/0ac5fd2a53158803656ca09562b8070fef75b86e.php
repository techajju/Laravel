

<?php $__env->startSection('main'); ?>

<?php 

$time = explode(':', $exam[0]['time']);

?>


<style>
    #submitdiv{
        width: 10%;
        margin-bottom: 30px;
    }
    .ans{
        margin: 0;
        padding: 0;
    }
</style>

<!-- exam-dashboard.blade -->
<div class="container">

        <p> 
            Welcome, <?php echo e(Auth::user()->name); ?>

        </p>
        <h1 class="text-center"><?php echo e($exam[0]['exam_name']); ?></h1>
        
        <?php $Q_count = 1; ?>
        <?php if($success == true): ?>
            <?php if(count($qna) > 0): ?>
            
           <!--  <form action="<?php echo e(route('examSubmit')); ?> " method="POST"    onsubmit="return isValid()"> -->
             <form action="<?php echo e(route('examSubmit')); ?> " method="POST" id="exam_form">
             <h4 class="text-right time"><?php echo e($exam[0]['time']); ?></h4> 

                 <?php echo csrf_field(); ?>
                <input type="hidden" name="exam_id" value="<?php echo e($exam[0]['id']); ?>">
               
                <?php $__currentLoopData = $qna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div> 
                            <h5> Q<?php echo e($Q_count ++); ?>.  <?php echo e($data['question'][0]['question']); ?></h5>
                            <input type="hidden" name ="q[]"value="<?php echo e($data['question'][0]['id']); ?>">
                            <input type="hidden" name="ans_<?php echo e($Q_count -1); ?>" id="ans_<?php echo e($Q_count -1); ?>">
                                 <?php $A_count = 1; ?>
                                <?php $__currentLoopData = $data['question'][0]['answer']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answars): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <p class="ans"> <b>Q<?php echo e($A_count ++); ?>).</b>  <?php echo e($answars['answer']); ?> 
                                <input type="radio" name="radio_<?php echo e($Q_count -1); ?>" data-id="<?php echo e($Q_count -1); ?>"class="select_ans" value="<?php echo e($answars['id']); ?>">
                            </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <br> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="text-center" id="submitdiv">
                    <input type="submit" class="btn btn-primary">
                </div>

                </form>
            <?php else: ?>
                <h3 style ="color:red" class="text-center">Question and Answers Are Not Avalible !</h3>
            <?php endif; ?>


        <?php else: ?>
            <h3 class="text-center" style="color:red"><?php echo e($msg); ?></h3>
        <?php endif; ?>
</div>

<script>

    $(document).ready(function(){
            $('.select_ans').click(function(){
                var no = $(this).attr("data-id");  
                $('#ans_'+no).val($(this).val());
            });

       var time = <?php echo json_encode($time, 15, 512) ?>;
       //console.log(time)     
        $('.time').text(time[0]+':'+time[1]+':00 Left Time');

        var secends = 60;
        var hours = parseInt(time[0]);
        var minutes = parseInt(time[1]);
            
           var timer = setInterval(() => {

                if( hours== 0 &&  secends== 0  && minutes == 0){
                    clearInterval(timer);
                    $("#exam_form").submit();
                }
               
                console.log(hours+" "+minutes + " " + secends )


                if(secends <= 0){
                    minutes--;
                    secends=60;

                }

                if(minutes <= 0  && hours != 0){
                    hours--;
                    minutes =60;
                    secends=60;
                    
                }

                    let Tempminutes = minutes.toString().length > 1? minutes :'0'+minutes;
                    let Temphours = hours.toString().length > 1? hours :'0'+hours;
                    let Tempsecends = secends.toString().length > 1? secends :'0'+secends;
  
                     $('.time').text(Temphours+':'+Tempminutes+':'+Tempsecends+': Left Time');

                 secends--;


            }, 1000);


 

    });

    function isValid(){
        var result = true;

        var qLentgh = parseInt("<?php echo e($Q_count); ?>")-1;
        $(".error_msg").remove();
        for(let i = 1; i <= qLentgh; i++ ){
            if($("#ans_"+i).val() == ""){
                result = false; 
                $("#ans_"+i).parent().append('<span style="color:red;" class="error_msg">Please select the answers</span>');
                setTimeout(() => {
                    $(".error_msg").remove();
                },5000);
            }

        }

        return result;

    }

</script>


<?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\students_man\resources\views/students/exam-dashboard.blade.php ENDPATH**/ ?>