
<?php $__env->startSection('admin_work'); ?>

<h2 class="mb-4">Students</h2>
 <!-- Button trigg0er modal -->
 <button type="button" class="btn btn-info" data-toggle="modal" data-target="#addstudentsanamodal">
  Add Students
  </button>
  <br><br>
  <br><br>
   <!-- Add exam Modal -->
     <!-- <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">    --> 
     <table class="table">
    <thead>
      <tr>
        <th scope="col">S.N</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>     
        <th scope="col">Edit</th>     
        <th scope="col">Delete</th>     
      </tr>
    </thead>
    <tbody>
       <?php if(count($students) > 0): ?>
            <?php $row = 1; ?>
          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td><?php echo e($row); ?></td> 
              <td><?php echo e($student->name); ?></td> 
              <td><?php echo e($student->email); ?></td>  
              <td>
                <button type="button"  data-id="<?php echo e($student->id); ?> " data-name="<?php echo e($student->name); ?>"data-email="<?php echo e($student->email); ?>"class="btn btn-info editButton" data-toggle="modal" data-target="#editstudentsanamodal">
                Edit 
              </button>
              </td>  
              <td>
                 <button class="btn btn-danger delet-btn delete_button_Std" data-id="<?php echo e($student->id); ?>" data-toggle="modal"data-target="#deleteStudents">Delete</button>      
              </td>
          </tr>  
          <?php $row++; ?>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
       <?php else: ?>
       <tr>
         <td aria-colspan="6"> No exam found !</td>
        </tr>
       <?php endif; ?>
    </tbody>
  </table>

  <!-- add question models box -->
<form id="addstudens">
    <?php echo csrf_field(); ?> 
     <div class="modal fade" id="addstudentsanamodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Add New Students</h5>
          
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
            <div class="modal-body">
                <div class="row">
                  <div class="col"> 
                  <input type="text" name="name"  placeholder="Enter Students Name" required>       
                 </div>
                </div>
                <div class="row">
                  <div class="col"> 
                  <input type="text" name="email" placeholder="Enter Students Email" required>       
                 </div>
                </div>
            </div>
          <div class="modal-footer">
            <p class="error"></p> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-info">Add New Students</button>
          </div>
        </div>
     </div>
    </div>
</form> 
<!-- /import Question and answers --> 

 <!-- add question models box -->
 <form id="editstudens">
    <?php echo csrf_field(); ?> 
     <div class="modal fade" id="editstudentsanamodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">update Students</h5>
          
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
            <div class="modal-body">
                <div class="row">
                  <div class="col"> 
                    <input type="hidden" name="id" id="id">
                  <input type="text" name="name"  id="name" placeholder="Enter Students Name" required>       
                 </div>
                </div>
                <div class="row">
                  <div class="col"> 
                  <input type="text" name="email" id="email" placeholder="Enter Students Email" required>       
                 </div>
                </div>
            </div>
          <div class="modal-footer">
            <p class="error"></p> 
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-info">Update</button>
          </div>
        </div>
     </div>
    </div>
</form> 
<!-- /edit student --> 

<!-- Delete Students -->
  <form id="deletstudent">
    <?php echo csrf_field(); ?>
     <div class="modal fade" id="deleteStudents" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Delete Question</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <h6>Are you soure you want delete this Studets</h6>
            <input type="hidden" id="deletestd" value=""  name="id">
            
           </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-danger">Delete</button>
          </div>
        </div>
      </div>
    </div>
  </form>
  <br><br>
<!-- /Delete Students -->


<script>
     $(document).ready(function(){
        $("#addstudens").submit(function(e){
            e.preventDefault(); 
            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('addStudets')); ?>",
                type:"POST",
                data: formData,
                success:function(data){
                    if(data.success == true){
                        location.reload();
                    }else{
                      alert(data.msg);
                 }
                }

            });

        });

        //edit student

        $(".editButton").click(function(){

          $("#id").val($(this).attr('data-id'));
          $("#name").val($(this).attr('data-name'));
          $("#email").val($(this).attr('data-email'));

        });

        $("#editstudens").submit(function(e){
            $(".editButton").prop("disabled",true);
            e.preventDefault(); 
            var formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('eidtStudets')); ?>",
                type:"POST",
                data: formData,
                success:function(data){
                    if(data.success == true){
                        location.reload();
                    }else{
                      alert(data.msg);
                 }
                }

            });

        });

        //Delete Students

        $(".delete_button_Std").click(function(){
          var id = $(this).attr("data-id");
            $("#deletestd").val(id);

            $("#deletstudent").submit(function(e){
              e.preventDefault();
              var formData = $(this).serialize();
              $.ajax({
                url: "<?php echo e(route('delete_students')); ?>",
                type:"POST",
                data:formData,
                success: function(data){
                  console.log(data)
                if (data.success == true) {
                  location.reload();
                    console.log(data.msg);
                } else {
                    alert(data.msg);
                }


                }


              });


            });

        });

      



     });



</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\students_man\resources\views/admin/studentsDashboard.blade.php ENDPATH**/ ?>