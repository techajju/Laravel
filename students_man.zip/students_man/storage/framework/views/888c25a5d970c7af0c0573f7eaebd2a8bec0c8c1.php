<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/admin.css')); ?>">
    <script src="<?php echo e(asset('js/jquery_new.js')); ?>"></script>
    <title>Document</title>
</head>
<body>

    <?php echo $__env->yieldContent('main'); ?>
</body>

    <script src="<?php echo e(asset('admin/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
</html><?php /**PATH C:\xampp\htdocs\students_man\resources\views/layouts/master.blade.php ENDPATH**/ ?>