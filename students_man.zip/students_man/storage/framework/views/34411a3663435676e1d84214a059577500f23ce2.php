    

        <?php $__env->startSection('admin_work'); ?>

    <h2 class="mb-4">Subject</h2>
    <style>
      input {
    overflow: visible;
    width: 100%;
}
    </style>
     <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addsubjectmodal">
        Add Subject
      </button>
  
  <!-- Add sub Modal -->
<form id="addSubjects" action="addSubject">
  <?php echo csrf_field(); ?>
   <div class="modal fade" id="addsubjectmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Add Subjects</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          
          <input type="text" id="sub_name" name ="sub_name" placeholder="Subject Name">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add Subject</button>
        </div>
      </div>
    </div>
  </div>
</form>

  <!-- Edit dub Modal -->
  <form id="editSubjects" action="editSubjects">
    <?php echo csrf_field(); ?>
     <div class="modal fade" id="editsubjectmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Edit Subjects</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            
            <input type="hidden" id="edit_sub_id" value=""  name="id">
            <input type="text" id="edit_sub_name" value="" name="sub_name_edit">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update</button>
          </div>
        </div>
      </div>
    </div>
  </form>

  <!-- Delete dub Modal -->
  <form id="deleteSubjects" action="deleteSubject">
    <?php echo csrf_field(); ?>
     <div class="modal fade" id="deletesubjectmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Delete Subjects</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <h6>Are you soure you want delete this subject</h6>
            <input type="hidden" id="delete_sub_id" value=""  name="id">
           </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-danger">Delete</button>
          </div>
        </div>
      </div>
    </div>
  </form>


<br><br>
<table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Subject</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
     <?php if(count($subjects) > 0): ?>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($sub->id); ?></td>
          <td><?php echo e($sub->subject); ?></td>
          <td>
              <button   class="btn btn-info edit-btn edit_button" data-id="<?php echo e($sub->id); ?>" data-subject="<?php echo e($sub->subject); ?>" data-toggle="modal"data-target="#editsubjectmodal">Edit</button>  
          </td>  

          <td>
            <button class="btn btn-danger delet-btn delete_button" data-id="<?php echo e($sub->id); ?>" data-toggle="modal"data-target="#deletesubjectmodal">Delete</button>  
          </td>  
        </tr>    

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     <?php else: ?>
     <tr>
       <td aria-colspan="4"> No subject found !</td>
      </tr>
     <?php endif; ?>
  </tbody>
</table>



<script>
  /* $(document).ready(function(){ */
    $("#addSubjects").submit(function(e) { 
       var formdata = $(this).serialize();
      $.ajax({
        url:"<?php echo e(route('addSubject')); ?>", 
        type:'POST',
        data: formdata,
        success:function(data){
          if(data.success == true)
          {
            location.reload();
          }
          else
          {
            alert(data.msg);
          }
        }

      });
      e.preventDefault();
    }); 


//edit subject
  $(".edit_button").click(function(){ 
       var data_id =  $(this).attr('data-id');
       var data_subject =  $(this).attr('data-subject');
 
        $("#edit_sub_name").val(data_subject);
        $("#edit_sub_id").val(data_id);
      });

      $("#editSubjects").submit(function(e) { 
       var formdata = $(this).serialize();
      $.ajax({
        url:"<?php echo e(route('editSubject')); ?>", 
        type:'POST',
        data: formdata,
        success:function(data){
          if(data.success == true)
          {
            location.reload();
          }
          else
          {
            alert(data.msg);
          }
        }

      });
      e.preventDefault();
    }); 

//Delete subject 
    $(".delete_button").click(function(){
      var subject_id = $(this).attr("data-id") 
      $("#delete_sub_id").val(subject_id);

      $("#deleteSubjects").submit(function(e) { 
       var formdata = $(this).serialize();
      $.ajax({
        url:"<?php echo e(route('deleteSubject')); ?>", 
        type:'POST',
        data: formdata,
        success:function(data){
          if(data.success == true)
          
          {
            location.reload();
          }
          else
          {
            alert(data.msg);
          }
        }

      });
      e.preventDefault();
    });


    });






   /*  }); */
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\students_man\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>